from setuptools import setup, find_packages

setup(
    name='KommatiTrading',
    version='1.0',
    author="Philip Mifsud",
    author_email="philmifsud97@gmail.com",
    packages=find_packages(),
)